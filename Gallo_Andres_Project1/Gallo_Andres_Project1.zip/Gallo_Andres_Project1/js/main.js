console.log("JS file is linked");

let firstName = "Marco";
let age= 20

ES6 template literals
console.log(´Hello ${firtsName}
	Andres´);
console.log("Hello" + firstName);